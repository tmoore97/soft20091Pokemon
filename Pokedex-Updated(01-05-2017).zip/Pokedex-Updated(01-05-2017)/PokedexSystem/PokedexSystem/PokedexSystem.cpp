// PokedexSystem.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
using namespace std;

class Pokemon {
public:
	void setDetails(string a, int b, string c, string d, string e, bool f)
	{
		name = a;
		natDexNo = b;
		primType = c;
		secType = d;
		dateCaught = e;
		evolves = f;
	};
	
	void displayDetails()
	{
		cout << endl << "Name: " + name << " | " << "National Dex Number: " << natDexNo <<
			endl << "Primary Type: " + primType << " | " << "Secondary Type: " + secType <<
			endl << "Date Caught: " + dateCaught << " | " << "Evolves: " << evolves << endl;
	};
	
	string returnName()
	{
		return name;
	};

	int returnDexNo()
	{
		return natDexNo;
	};

	string returnTypes()
	{
		string types = primType + "/" + secType;
		return types;
	};

	string returnDate()
	{
		return dateCaught;
	};

	bool returnEvolves() 
	{
		return evolves;
	}

protected:
	string name;
	int natDexNo;
	string primType;
	string secType;
	string dateCaught;
	bool evolves;
};

class evolvingPokemon : public Pokemon{
public:
	string returnEvolutionTree()
	{
		return evolvesFrom + evolvesInto;
	};
	void setDetails(string a, int b, string c, string d, string e, bool f, string g, string h)
	{
		name = a;
		natDexNo = b;
		primType = c;
		secType = d;
		dateCaught = e;
		evolves = f;
		evolvesFrom = g;
		evolvesInto = h;
	};
	void displayDetails()
	{
		cout << endl << "Name: " + name << " | " << "National Dex Number: " << natDexNo <<
			endl << "Primary Type: " + primType << " | " << "Secondary Type: " + secType <<
			endl << "Date Caught: " + dateCaught << " | " << "Evolves: " << evolves <<
			endl << "Evolves From: " + evolvesFrom << " | " << "Evolves Into: " + evolvesInto << endl;
	};
protected:
	string evolvesFrom;
	string evolvesInto;
};

class nonEvolvingPokemon : public Pokemon{
public:
	bool returnEvolves()
	{
		return false;
	}
};

vector<Pokemon> Pokedex;
int mainMenu(int input);
int viewMenu(int input);
int searchMenu(int input);
Pokemon addNewPokemon();
vector<Pokemon> mergeSort(vector<Pokemon> listToSort, string mergetype);
vector<Pokemon> mergeDexNo(vector<Pokemon> left, vector<Pokemon> right);
vector<Pokemon> mergeString(vector<Pokemon> left, vector<Pokemon> right, string sortingBy);


int main()
{
	int choice = 0;
	while (choice != 5)
	{
		cout << "Welcome to the Pokedex system. Please select from the options below what you would like to do, using the number keys:" << endl <<
			"1: Add New Pokemon" << endl <<
			"2: View Pokedex" << endl <<
			"3: Search Pokedex" << endl <<
			"4: Delete From Pokedex" << endl <<
			"5: Close Pokedex" << endl;
		cin >> choice;
		mainMenu(choice);
	}
	
    return 0;
}

int mainMenu(int input)
{
	int choice = 0;
	switch (input){
	case 1:
		// Adding Pokemon
		Pokedex.push_back(addNewPokemon());
		break;
	case 2:
		// View and sort
		cout << "Please select how you wish to the Pokedex to be displayed, using the number keys:" << endl <<
			"1: By ID (Default)" << endl <<
			"2: By National Dex Number" << endl <<
			"3: By Name" << endl <<
			"4: By Type" << endl <<
			"5: View Evolving Only" << endl <<
			"6: View Non-Evolving Only" << endl <<
			"Any other key: Return to menu" << endl;
		cin >> choice;
		viewMenu(choice);
		break;
	case 3:
		// Search
		cout << "Please what you wish to search by, using the number keys:" << endl <<
			"1: By ID (Default)" << endl <<
			"2: By National Dex Number" << endl <<
			"3: By Name" << endl <<
			"4: By Type" << endl <<
			"Any other key: Return to menu" << endl;
		cin >> choice;
		searchMenu(choice);
		break;
	//case 4:
		// Delete
		//break;
	case 5:
		cout << "Thank you for using the Pokedex. Goodbye." << endl;
		break;
	default:
		cout << "Sorry, please try again." << endl;
		cin.clear();
		cin.ignore(256, '\n');
	}

	return input;
}

Pokemon addNewPokemon()
{
	time_t currentTime;
	struct tm localTime;

	time(&currentTime);                  
	localtime_s(&localTime, &currentTime);

	string Pname = "";
	int PDexNo = 0;
	int typeChoice = 0;
	string PprimType = "";
	string PsecType = "";
	string PdateCaught;

	int Day = localTime.tm_mday;
	int Month = localTime.tm_mon + 1;
	int Year = localTime.tm_year + 1900;

	string PevChoice;
	bool Pevolves;
	string PevolvesFrom;
	string PevolvesInto;
	
	evolvingPokemon newEvPoke;
	nonEvolvingPokemon newNonEvPoke;

	cout << "Enter the name of the Pokemon" << endl;
	cin >> Pname;

	for (unsigned int i = 0; i < Pname.length(); i++)
	{
		Pname [i] = toupper(Pname[i]);
	}
	// Call search function to check for matching name already existing here

	cout << "Enter the National Dex Number of the Pokemon" << endl;
	cin >> PDexNo;

	while (cin.fail())
	{
		cout << "Sorry, please try again." << 
		endl << "Enter the National Dex Number of the Pokemon" << endl;
		cin.clear();
		cin.ignore(256,'\n');
		cin >> PDexNo;
	}

	while (PprimType == "")
	{
		cout << "Select the Primary Type of the Pokemon using the numbers 1 - 18. The types are:" << endl <<
			"1: NORMAL, 2: FIRE, 3: WATER" << endl <<
			"4: ELECTRIC, 5: GRASS, 6: ICE" << endl <<
			"7: FIGHTING, 8: POISON, 9: GROUND" << endl <<
			"10: FLYING, 11: PSYCHIC,  12: BUG" << endl <<
			"13: ROCK, 14: GHOST, 15: DRAGON" << endl <<
			"16: DARK, 17: STEEL, 18 FAIRY" << endl;
		cin >> typeChoice;

		switch (typeChoice)
		{
		case 1:
			PprimType = "Normal";
			break;
		case 2:
			PprimType = "Fire";
			break;
		case 3:
			PprimType = "Water";
			break;
		case 4:
			PprimType = "Electric";
			break;
		case 5:
			PprimType = "Grass";
			break;
		case 6:
			PprimType = "Ice";
			break;
		case 7:
			PprimType = "Fighting";
			break;
		case 8:
			PprimType = "Poison";
			break;
		case 9:
			PprimType = "Ground";
			break;
		case 10:
			PprimType = "Flying";
			break;
		case 11:
			PprimType = "Psychic";
			break;
		case 12:
			PprimType = "Bug";
			break;
		case 13:
			PprimType = "Rock";
			break;
		case 14:
			PprimType = "Ghost";
			break;
		case 15:
			PprimType = "Dragon";
			break;
		case 16:
			PprimType = "Dark";
			break;
		case 17:
			PprimType = "Steel";
			break;
		case 18:
			PprimType = "Fairy";
			break;
		default:
			cout << "Sorry, please try again." << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	}


	for (unsigned int i = 0; i < PprimType.length(); i++)
	{
		PprimType[i] = toupper(PprimType[i]);
	}

	while (PsecType == "")
	{
		cout << "Select the Secondary Type of the Pokemon using the numbers 0 - 18. The types are:" << endl <<
			"0: No secondary type" << endl <<
			"1: NORMAL, 2: FIRE, 3: WATER" << endl <<
			"4: ELECTRIC, 5: GRASS, 6: ICE" << endl <<
			"7: FIGHTING, 8: POISON, 9: GROUND" << endl <<
			"10: FLYING, 11: PSYCHIC,  12: BUG" << endl <<
			"13: ROCK, 14: GHOST, 15: DRAGON" << endl <<
			"16: DARK, 17: STEEL, 18 FAIRY" << endl;
		cin >> typeChoice;

		switch (typeChoice)
		{
		case 0: 
			PsecType = "None";
			break;
		case 1:
			PsecType = "Normal";
			break;
		case 2:
			PsecType = "Fire";
			break;
		case 3:
			PsecType = "Water";
			break;
		case 4:
			PsecType = "Electric";
			break;
		case 5:
			PsecType = "Grass";
			break;
		case 6:
			PsecType = "Ice";
			break;
		case 7:
			PsecType = "Fighting";
			break;
		case 8:
			PsecType = "Poison";
			break;
		case 9:
			PsecType = "Ground";
			break;
		case 10:
			PsecType = "Flying";
			break;
		case 11:
			PsecType = "Psychic";
			break;
		case 12:
			PsecType = "Bug";
			break;
		case 13:
			PsecType = "Rock";
			break;
		case 14:
			PsecType = "Ghost";
			break;
		case 15:
			PsecType = "Dragon";
			break;
		case 16:
			PsecType = "Dark";
			break;
		case 17:
			PsecType = "Steel";
			break;
		case 18:
			PsecType = "Fairy";
			break;
		default:
			cout << "Sorry, please try again." << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	}


	for (unsigned int i = 0; i < PsecType.length(); i++)
	{
		PsecType[i] = toupper(PsecType[i]);
	}

	PdateCaught = to_string(Day) + "/" + to_string(Month) + "/" + to_string(Year);


	while (true){
		cout << "Does this Pokemon evolve? Please reply with a 'y' or 'n'." << endl;
		cin >> PevChoice;

		if (PevChoice == "y")
		{
			Pevolves = true;
			cout << "What does it evolve from? Enter 'n' if it doesn't have a prevolution." << endl;
			cin >> PevolvesFrom;
			if (PevolvesFrom == "n")
				PevolvesFrom = "";
			cout << "What does it evolve to? Enter 'n' if it doesn't have an evolution." << endl;
			cin >> PevolvesInto;
			if (PevolvesInto == "n")
				PevolvesInto = "";
			
			newEvPoke.setDetails(Pname, PDexNo, PprimType, PsecType, PdateCaught, Pevolves, PevolvesFrom, PevolvesInto);
			return newEvPoke;
		}
		else if (PevChoice == "n")
		{
			Pevolves = false;
			newNonEvPoke.setDetails(Pname,PDexNo,PprimType,PsecType,PdateCaught,Pevolves);
			return newNonEvPoke;
		}
		else
		{
			cout << "Sorry, please try again." << endl;
			cout << "Does this Pokemon evolve? Please reply with a 'y' or 'n'." << endl;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> PevChoice;
		}
	}


	return newNonEvPoke;

}

int viewMenu(int input)
{
	vector<Pokemon> sortedPokedex;
	switch (input) {
	case 1:
		// View by ID
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			Pokedex[i].displayDetails();
		}
		break;
	case 2:
		// View by Nat Dex No.
		sortedPokedex = mergeSort(Pokedex, "natdex");
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			sortedPokedex[i].displayDetails();
		}
		break;
	case 3:
		// View by Name
		sortedPokedex = mergeSort(Pokedex, "name");
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			sortedPokedex[i].displayDetails();
		}
		break;
	case 4:
		// View by Type
		sortedPokedex = mergeSort(Pokedex, "type");
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			sortedPokedex[i].displayDetails();
		}
		break;
	case 5:
		// View only evolving
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (Pokedex[i].returnEvolves())
				Pokedex[i].displayDetails();
		}
		break;
	case 6:
		// View only non-evolving
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (!Pokedex[i].returnEvolves())
				Pokedex[i].displayDetails();
		}
		break;
	default:
		return input;
	}
	return input;
}

int searchMenu(int input)
{
	vector<Pokemon> resultOfSearch;
	int searchTermInt;
	string searchTermString;
	switch (input) {
	case 1:
		// Search by ID
		cout << "Enter the ID you wish to search by: ";
		cin >> searchTermInt;
		while (cin.fail())
		{
			cout << "Sorry, please try again." <<
				endl << "Enter the ID you wish to search by: ";;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> searchTermInt;
		}

		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (i == searchTermInt)
				Pokedex[i].displayDetails();
		}
		break;
	case 2:
		// Search by Nat Dex No
		cout << "Enter the National Dex Number you wish to search by: ";
		cin >> searchTermInt;
		while (cin.fail())
		{
			cout << "Sorry, please try again." <<
				endl << "Enter the National Dex Number you wish to search by: ";;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> searchTermInt;
		}

		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (Pokedex[i].returnDexNo() == searchTermInt)
				Pokedex[i].displayDetails();
		}
		break;
	case 3:
		// View by Name
		resultOfSearch = mergeSort(Pokedex, "name");
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			resultOfSearch[i].displayDetails();
		}
		break;
	case 4:
		// View by Type
		resultOfSearch = mergeSort(Pokedex, "type");
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			resultOfSearch[i].displayDetails();
		}
		break;
	default:
		return input;
	}
	return input;
}

vector<Pokemon> mergeSort(vector<Pokemon> listToSort, string mergetype)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	// Follows the same logic, but optimised to handle a vector of Pokemon rather than ints

	// check to see if list is too small to sort
	if (listToSort.size() <= 1)
		return listToSort;

	vector<Pokemon> left, right, result;

	int middle = ((int)listToSort.size() + 1) / 2;

	for (int i = 0; i < middle; i++) {
		left.push_back(listToSort[i]);
	}

	for (int i = middle; i < (int)listToSort.size(); i++) {
		right.push_back(listToSort[i]);
	}

	left = mergeSort(left, mergetype);
	right = mergeSort(right, mergetype);

	if (mergetype == "natdex")
		result = mergeDexNo(left, right);
	else
		result = mergeString(left, right, mergetype);

	return result;
}

vector<Pokemon> mergeDexNo(vector<Pokemon> left, vector<Pokemon> right)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	vector<Pokemon> result;

	while ((int)left.size() > 0 || (int)right.size() > 0) {

		if ((int)left.size() > 0 && (int)right.size() > 0) {
			
			if ((int)left.front().returnDexNo() <= (int)right.front().returnDexNo()) {
				result.push_back(left.front());
				left.erase(left.begin());
			}
			else {
				result.push_back(right.front());
				right.erase(right.begin());
			}
		}
		else if ((int)left.size() > 0) {
			for (int i = 0; i < (int)left.size(); i++)
				result.push_back(left[i]);
			break;
		}
		else if ((int)right.size() > 0) {
			for (int i = 0; i < (int)right.size(); i++)
				result.push_back(right[i]);
			break;
		}
	}
	return result;
}

vector<Pokemon> mergeString(vector<Pokemon> left, vector<Pokemon> right, string sortingBy)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	vector<Pokemon> result;
	
	while ((int)left.size() > 0 || (int)right.size() > 0) {

		if ((int)left.size() > 0 && (int)right.size() > 0) {
			
			if (sortingBy == "name")
			{
				if ((string)left.front().returnName() <= (string)right.front().returnName()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}
			
			else if (sortingBy == "type")
			{
				if ((string)left.front().returnTypes() <= (string)right.front().returnTypes()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}
		
		}
		else if ((int)left.size() > 0) {
			for (int i = 0; i < (int)left.size(); i++)
				result.push_back(left[i]);
			break;
		}
		else if ((int)right.size() > 0) {
			for (int i = 0; i < (int)right.size(); i++)
				result.push_back(right[i]);
			break;
		}
	}
	return result;
}