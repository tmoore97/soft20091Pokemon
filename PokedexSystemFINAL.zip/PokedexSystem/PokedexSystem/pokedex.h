#pragma once

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <string.h>
#include "pokemon.h"

using namespace std;

class PokedexSystem {
public:
	int mainMenu(int input);
	int viewMenu(int input);
	int searchMenu(int input);

	Pokemon addNewPokemon(bool addingEvolution, bool addingPrevolution, string evolutionName);
	bool searchPokedex(string searchType, int searchParameterInt, string searchParameterString, size_t systemIDSearch, bool systemSearch);
	void deleteRecord(vector<Pokemon> results, vector<evolvingPokemon> evolvingResults);

	vector<Pokemon> mergeSort(vector<Pokemon> listToSort, string mergetype);
	vector<Pokemon> merge(vector<Pokemon> left, vector<Pokemon> right, string sortingBy);
	vector<evolvingPokemon> mergeSortEvolving(vector<evolvingPokemon> listToSort, string mergetype);
	vector<evolvingPokemon> mergeEvolving(vector<evolvingPokemon> left, vector<evolvingPokemon> right, string sortingBy);
private:
	vector<Pokemon> Pokedex;
	vector<evolvingPokemon> evolvingPokedex;

};

