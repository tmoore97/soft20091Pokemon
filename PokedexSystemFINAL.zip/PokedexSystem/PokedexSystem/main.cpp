// PokedexSystem.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>

//Custom includes
#include "pokemon.h"
#include "pokedex.h"

using namespace std;

PokedexSystem Dex;

int main()
{
	int choice = 0;
	while (choice != 4)
	{
		cout << endl << "Welcome to the Pokedex system. Please select from the options below what you would like to do, using the number keys:" << endl <<
			"1: Add New Pokemon" << endl <<
			"2: View Pokedex" << endl <<
			"3: Search and Delete From Pokedex" << endl <<
			"4: Close Pokedex" << endl;
		cin >> choice;
		Dex.mainMenu(choice);
	}
	
    return 0;
}