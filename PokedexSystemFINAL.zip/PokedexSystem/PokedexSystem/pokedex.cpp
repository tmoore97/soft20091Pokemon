#include "stdafx.h"
#include "pokedex.h"

int PokedexSystem::mainMenu(int input)
{
	int choice = 0;
	string filename = "";

	switch (input) {
	case 1:
		// Adding Pokemon
		addNewPokemon(false, false, "");
		break;
	case 2:
		// View and sort
		cout << "Please select how you wish to the Pokedex to be displayed, using the number keys:" << endl <<
			"1: By ID (Default)" << endl <<
			"2: By National Dex Number" << endl <<
			"3: By Name" << endl <<
			"4: By Type" << endl <<
			"5: View Evolving Only" << endl <<
			"6: View Non-Evolving Only" << endl <<
			"Any other key: Return to menu" << endl;
		cin >> choice;
		viewMenu(choice);
		break;
	case 3:
		// Search
		cout << "Please what you wish to search by, using the number keys:" << endl <<
			"1: By ID (Default)" << endl <<
			"2: By National Dex Number" << endl <<
			"3: By Name" << endl <<
			"4: By Type" << endl <<
			"Any other key: Return to menu" << endl;
		cin >> choice;
		searchMenu(choice);
		break;
	case 4:
		cout << "Thank you for using the Pokedex. Goodbye." << endl;
		break;


	default:
		cout << "Sorry, please try again." << endl;
		cin.clear();
		cin.ignore(256, '\n');
	}

	return input;
}

Pokemon PokedexSystem::addNewPokemon(bool addingEvolution, bool addingPrevolution, string evolutionName)
{
	time_t currentTime;
	struct tm localTime;

	time(&currentTime);
	localtime_s(&localTime, &currentTime);

	string Pname = "";
	int PDexNo = 0;
	int typeChoice = 0;
	string PprimType = "";
	string PsecType = "";
	string PdateCaught;

	int Day = localTime.tm_mday;
	int Month = localTime.tm_mon + 1;
	int Year = localTime.tm_year + 1900;

	string PevChoice;
	bool Pevolves;
	size_t PID;

	string PevolvesFrom;
	string PevolvesInto;

	evolvingPokemon newEvPoke;
	nonEvolvingPokemon newNonEvPoke;

	cout << "Enter the name of the Pokemon" << endl;
	cin >> Pname;

	for (unsigned int i = 0; i < Pname.length(); i++)
	{
		Pname[i] = toupper(Pname[i]);
	}

	// Call search function to check for matching name already existing here
	if (searchPokedex("name", 0, Pname, 0, true))
	{
		cout << "ERROR: Pokemon already exists. Please try again." << endl;
		return newEvPoke;
	}

	cout << "Enter the National Dex Number of the Pokemon" << endl;
	cin >> PDexNo;

	while (cin.fail())
	{
		cout << "Sorry, please try again." <<
			endl << "Enter the National Dex Number of the Pokemon" << endl;
		cin.clear();
		cin.ignore(256, '\n');
		cin >> PDexNo;
	}

	if (searchPokedex("natdex", PDexNo, "", 0, true))
	{
		cout << "ERROR: Pokemon already exists. Please try again." << endl;
		return newEvPoke;
	}
	// Call search function to check for matching DexNo already existing here

	while (PprimType == "")
	{
		cout << "Select the Primary Type of the Pokemon using the numbers 1 - 18. The types are:" << endl <<
			"1: NORMAL, 2: FIRE, 3: WATER" << endl <<
			"4: ELECTRIC, 5: GRASS, 6: ICE" << endl <<
			"7: FIGHTING, 8: POISON, 9: GROUND" << endl <<
			"10: FLYING, 11: PSYCHIC,  12: BUG" << endl <<
			"13: ROCK, 14: GHOST, 15: DRAGON" << endl <<
			"16: DARK, 17: STEEL, 18: FAIRY" << endl;
		cin >> typeChoice;

		switch (typeChoice)
		{
		case 1:
			PprimType = "Normal";
			break;
		case 2:
			PprimType = "Fire";
			break;
		case 3:
			PprimType = "Water";
			break;
		case 4:
			PprimType = "Electric";
			break;
		case 5:
			PprimType = "Grass";
			break;
		case 6:
			PprimType = "Ice";
			break;
		case 7:
			PprimType = "Fighting";
			break;
		case 8:
			PprimType = "Poison";
			break;
		case 9:
			PprimType = "Ground";
			break;
		case 10:
			PprimType = "Flying";
			break;
		case 11:
			PprimType = "Psychic";
			break;
		case 12:
			PprimType = "Bug";
			break;
		case 13:
			PprimType = "Rock";
			break;
		case 14:
			PprimType = "Ghost";
			break;
		case 15:
			PprimType = "Dragon";
			break;
		case 16:
			PprimType = "Dark";
			break;
		case 17:
			PprimType = "Steel";
			break;
		case 18:
			PprimType = "Fairy";
			break;
		default:
			cout << "Sorry, please try again." << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	}


	for (unsigned int i = 0; i < PprimType.length(); i++)
	{
		PprimType[i] = toupper(PprimType[i]);
	}

	while (PsecType == "")
	{
		cout << "Select the Secondary Type of the Pokemon using the numbers 0 - 18. The types are:" << endl <<
			"0: No secondary type" << endl <<
			"1: NORMAL, 2: FIRE, 3: WATER" << endl <<
			"4: ELECTRIC, 5: GRASS, 6: ICE" << endl <<
			"7: FIGHTING, 8: POISON, 9: GROUND" << endl <<
			"10: FLYING, 11: PSYCHIC,  12: BUG" << endl <<
			"13: ROCK, 14: GHOST, 15: DRAGON" << endl <<
			"16: DARK, 17: STEEL, 18: FAIRY" << endl;
		cin >> typeChoice;

		switch (typeChoice)
		{
		case 0:
			PsecType = "None";
			break;
		case 1:
			PsecType = "Normal";
			break;
		case 2:
			PsecType = "Fire";
			break;
		case 3:
			PsecType = "Water";
			break;
		case 4:
			PsecType = "Electric";
			break;
		case 5:
			PsecType = "Grass";
			break;
		case 6:
			PsecType = "Ice";
			break;
		case 7:
			PsecType = "Fighting";
			break;
		case 8:
			PsecType = "Poison";
			break;
		case 9:
			PsecType = "Ground";
			break;
		case 10:
			PsecType = "Flying";
			break;
		case 11:
			PsecType = "Psychic";
			break;
		case 12:
			PsecType = "Bug";
			break;
		case 13:
			PsecType = "Rock";
			break;
		case 14:
			PsecType = "Ghost";
			break;
		case 15:
			PsecType = "Dragon";
			break;
		case 16:
			PsecType = "Dark";
			break;
		case 17:
			PsecType = "Steel";
			break;
		case 18:
			PsecType = "Fairy";
			break;
		default:
			cout << "Sorry, please try again." << endl;
			cin.clear();
			cin.ignore(256, '\n');
		}
	}


	for (unsigned int i = 0; i < PsecType.length(); i++)
	{
		PsecType[i] = toupper(PsecType[i]);
	}

	PdateCaught = to_string(Day) + "/" + to_string(Month) + "/" + to_string(Year);

	PID = Pokedex.size();

	while (searchPokedex("id", 0, "", PID, true))
	{
		PID = PID + 1;
	}


	while (true) {
		cout << "Does this Pokemon evolve? Please reply with a 'y' or 'n'." << endl;
		cin >> PevChoice;

		if (PevChoice == "y")
		{
			Pevolves = true;

			if (addingEvolution && !addingPrevolution)
			{
				cout << "What does it evolve to? Enter 'n' if it doesn't have an evolution." << endl;
				cin >> PevolvesInto;

				if (PevolvesInto != "n")
				{
					// Search for Pokemon by name, if it returns false, ask them to create the pokemon 
					if (!searchPokedex("name", 0, PevolvesInto, 0, true))
					{
						cout << "Please add the evolution to the Pokedex" << endl;
						addNewPokemon(true, false, Pname);
					}
				}
				else 
				{
					PevolvesInto = "";
				}
				PevolvesFrom = evolutionName;
			}

			else if (addingPrevolution && !addingEvolution)
			{
				cout << "What does it evolve from? Enter 'n' if it doesn't have a prevolution." << endl;
				cin >> PevolvesFrom;
				if (PevolvesFrom != "n")
				{
					// Search for Pokemon by name, if it returns false, ask them to create the pokemon 
					if (!searchPokedex("name", 0, PevolvesFrom, 0, true))
					{
						cout << "Please add the prevolution to the Pokedex" << endl;
						addNewPokemon(false, true, Pname);
					}
				}
				else
				{
					PevolvesFrom = "";
				}
				PevolvesInto = evolutionName;
				cout << "Registered prevolution. The next question will be about your previous Pokemon entry.";
			}


			else 
			{
				cout << "What does it evolve from? Enter 'n' if it doesn't have a prevolution." << endl;
				cin >> PevolvesFrom;
				if (PevolvesFrom != "n")
				{
					// Search for Pokemon by name, if it returns false, ask them to create the pokemon 
					if (!searchPokedex("name", 0, PevolvesFrom, 0, true))
					{
						cout << "Please add the prevolution to the Pokedex" << endl;
						addNewPokemon(false, true, Pname);
					}
				}
				else {
					PevolvesFrom = "";
				}


				cout << "What does it evolve to? Enter 'n' if it doesn't have an evolution." << endl;
				cin >> PevolvesInto;

				if (PevolvesInto != "n")
				{
					// Search for Pokemon by name, if it returns false, ask them to create the pokemon 
					if (!searchPokedex("name", 0, PevolvesInto, 0, true))
					{
						cout << "Please add the evolution to the Pokedex" << endl;
						addNewPokemon(true, false, Pname);
					}
				}
				else
					PevolvesInto = "";

			}
			
				
			for (unsigned int i = 0; i < PevolvesInto.size(); i++)	
			{
				PevolvesInto[i] = toupper(PevolvesInto[i]);
			}

			for (unsigned int i = 0; i < PevolvesFrom.size(); i++)
			{
				PevolvesFrom[i] = toupper(PevolvesFrom[i]);
			}

			cout << "Pokemon registered" << endl << endl;
			newEvPoke.setDetails(Pname, PDexNo, PprimType, PsecType, PdateCaught, Pevolves, PID, PevolvesFrom, PevolvesInto);
			Pokedex.push_back(newEvPoke);
			evolvingPokedex.push_back(newEvPoke);
			return newEvPoke;
		}
		else if (PevChoice == "n")
		{
			Pevolves = false;
			newNonEvPoke.setDetails(Pname, PDexNo, PprimType, PsecType, PdateCaught, Pevolves, PID);
			Pokedex.push_back(newNonEvPoke);
			return newNonEvPoke;
		}
		else
		{
			cout << "Sorry, please try again." << endl;
			cout << "Does this Pokemon evolve? Please reply with a 'y' or 'n'." << endl;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> PevChoice;
		}
	}


	return newNonEvPoke;

}

int PokedexSystem::viewMenu(int input)
{
	switch (input) {
	case 1:
		// View by ID
		Pokedex = mergeSort(Pokedex, "id");
		evolvingPokedex = mergeSortEvolving(evolvingPokedex, "id");
		break;
	case 2:
		// View by Nat Dex No.
		Pokedex = mergeSort(Pokedex, "natdex");
		evolvingPokedex = mergeSortEvolving(evolvingPokedex, "natdex");
		break;
	case 3:
		// View by Name
		Pokedex = mergeSort(Pokedex, "name");
		evolvingPokedex = mergeSortEvolving(evolvingPokedex, "name");
		break;
	case 4:
		// View by Type
		Pokedex = mergeSort(Pokedex, "type");
		evolvingPokedex = mergeSortEvolving(evolvingPokedex, "type");
		break;
	case 5:
		// View only evolving
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			evolvingPokedex[i].displayDetails();
		}
		break;
	case 6:
		// View only non-evolving
		cout << endl << endl << "POKEDEX: " << endl;
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (!Pokedex[i].returnEvolves())
				Pokedex[i].displayDetails();
		}
		break;
	default:
		cin.clear();
		cin.ignore(256, '\n');
		return input;
	}
	for (unsigned int i = 0; i < Pokedex.size(); i++)
	{
		if (Pokedex[i].returnEvolves())
		{
			for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
			{
				if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
				{
					evolvingPokedex[j].displayDetails();
				}
			}
		}
		else
		{
			Pokedex[i].displayDetails();
		}
	}
	return input;
}

int PokedexSystem::searchMenu(int input)
{
	vector<Pokemon> resultOfSearch;
	int searchTermInt;
	string searchTermString;

	switch (input) {
	case 1:
		// Search by ID
		cout << "Enter the ID you wish to search by: ";
		cin >> searchTermInt;
		while (cin.fail())
		{
			cout << "Sorry, please try again." <<
				endl << "Enter the ID you wish to search by: ";;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> searchTermInt;
		}
		searchPokedex("id", searchTermInt, "", 0, false);
		break;
	case 2:
		// Search by Nat Dex No
		cout << "Enter the National Dex Number you wish to search by: ";
		cin >> searchTermInt;
		while (cin.fail())
		{
			cout << "Sorry, please try again." <<
				endl << "Enter the National Dex Number you wish to search by: ";;
			cin.clear();
			cin.ignore(256, '\n');
			cin >> searchTermInt;
		}
		searchPokedex("natdex", searchTermInt, "", 0, false);
		break;
	case 3:
		// View by Name
		cout << "Enter the Name you wish to search by: ";
		cin >> searchTermString;

		searchPokedex("name", 0, searchTermString, 0, false);
		break;
	case 4:
		// View by Type
		cout << "Enter the Type you wish to search by: ";
		cin >> searchTermString;
		searchPokedex("type", 0, searchTermString, 0, false);
		break;
	default:
		cin.clear();
		cin.ignore(256, '\n');
		return input;
	}
	return input;
}

bool PokedexSystem::searchPokedex(string searchType, int searchParameterInt, string searchParameterString, size_t systemIDSearch, bool systemSearch)
{
	size_t found;
	vector<Pokemon> results;
	vector<evolvingPokemon> evolvingResults;

	for (unsigned int i = 0; i < searchParameterString.length(); i++)
	{
		searchParameterString[i] = toupper(searchParameterString[i]);
	}

	if (searchType == "id")
	{
		if (systemSearch)
		{

			for (unsigned int i = 0; i < Pokedex.size(); i++)
			{
				if (Pokedex[i].returnID() == systemIDSearch)
				{
					if (Pokedex[i].returnEvolves())
					{
						for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
						{
							if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
							{
								evolvingResults.push_back(evolvingPokedex[j]);
							}
						}
						
					}
					else
					{
						results.push_back(Pokedex[i]);
					}
				}
			}
		}
		else
		{
			for (unsigned int i = 0; i < Pokedex.size(); i++)
			{
				if (Pokedex[i].returnID() == searchParameterInt)
				{
					if (Pokedex[i].returnEvolves())
					{
						for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
						{
							if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
							{
								evolvingResults.push_back(evolvingPokedex[j]);
							}
						}
					}
					else
					{
						results.push_back(Pokedex[i]);
					}
				}
			}
		}
	}
	else if (searchType == "natdex")
	{
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			if (Pokedex[i].returnDexNo() == searchParameterInt)
			{
				if (Pokedex[i].returnEvolves())
				{
					for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
					{
						if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
						{
							evolvingResults.push_back(evolvingPokedex[j]);
						}
					}
				}
				else
				{
					results.push_back(Pokedex[i]);
				}
			}
		}
	}
	else if (searchType == "name")
	{
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			found = Pokedex[i].returnName().find(searchParameterString);
			if (found != string::npos)
			{
				if (Pokedex[i].returnEvolves())
				{
					for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
					{
						if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
						{
							evolvingResults.push_back(evolvingPokedex[j]);
						}
					}
				}
				else
				{
					results.push_back(Pokedex[i]);
				}
			}
		}
	}
	else if (searchType == "type")
	{
		for (unsigned int i = 0; i < Pokedex.size(); i++)
		{
			found = Pokedex[i].returnTypes().find(searchParameterString);
			if (found != string::npos)
			{
				if (Pokedex[i].returnEvolves())
				{
					for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
					{
						if (Pokedex[i].returnName() == evolvingPokedex[j].returnName())
						{
							evolvingResults.push_back(evolvingPokedex[j]);
						}
					}
				}
				else
				{
					results.push_back(Pokedex[i]);
				}
			}
		}
	}

	if (!systemSearch)
	{
		deleteRecord(results,evolvingResults);
	}

	if (results.size() != 0 || evolvingResults.size() != 0)
	{
		return true;
	}


	return false;
}

void PokedexSystem::deleteRecord(vector<Pokemon> results, vector<evolvingPokemon> evolvingResults)
{
	string choice;
	int idChosen;
	int deleteThis = 0;
	int deleteEvolves = 0;
	bool recordFound = false;

	// Displaying results
	cout << endl << endl << "POKEDEX: " << endl;
	for (unsigned int i = 0; i < results.size(); i++)
	{
		results[i].displayDetails();
	}

	for (unsigned int i = 0; i < evolvingResults.size(); i++)
	{
		evolvingResults[i].displayDetails();
	}

	//Deleting section

	cout << "Do you wish to delete any of the above records from the Pokedex? Enter 'y' or 'n'." << endl;
	cin >> choice;
	while (true) {
		if (choice == "n")
		{
			// Does nothing and leaves the function.
			break;
		}
		else if (choice == "y")
		{
			// Enter ID, delete record
			cout << "Enter the ID of the record you wish to delete." << endl;
			cin >> idChosen;
			while (cin.fail())
			{
				cout << "Sorry, please try again." << endl;
				cin.clear();
				cin.ignore(256, '\n');
				cout << "Enter the ID of the record you wish to delete." << endl;
				cin >> idChosen;
			}
			for (unsigned int i = 0; i < Pokedex.size(); i++)
			{
				if (idChosen == Pokedex[i].returnID())
				{
					recordFound = true;
					deleteThis = i;
				}
			}

			if (recordFound)
			{
				if (Pokedex[deleteThis].returnEvolves())
				{
					for (unsigned int j = 0; j < evolvingPokedex.size(); j++)
					{
						if (Pokedex[deleteThis].returnName() == evolvingPokedex[j].returnName())
						{
							deleteEvolves = j;
						}
					}
					evolvingPokedex.erase(evolvingPokedex.begin() + deleteEvolves);
					
				}
				Pokedex.erase(Pokedex.begin() + deleteThis);
			}
			else
			{
				cout << "No matching record found." << endl;
			}
			break;
		}
		else
		{
			cout << "Sorry, please try again." << endl;
			cin.clear();
			cin.ignore(256, '\n');
			cout << "Do you wish to delete any of the above records from the Pokedex? Enter 'y' or 'n'. ";
			cin >> choice;
		}

	}
}

vector<Pokemon> PokedexSystem::mergeSort(vector<Pokemon> listToSort, string mergetype)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	// Follows the same logic, but optimised to handle a vector of Pokemon rather than ints

	// check to see if list is too small to sort
	if (listToSort.size() <= 1)
		return listToSort;

	vector<Pokemon> left, right, result;

	int middle = ((int)listToSort.size() + 1) / 2;

	for (int i = 0; i < middle; i++) {
		left.push_back(listToSort[i]);
	}

	for (int i = middle; i < (int)listToSort.size(); i++) {
		right.push_back(listToSort[i]);
	}

	left = mergeSort(left, mergetype);
	right = mergeSort(right, mergetype);


	result = merge(left, right, mergetype);

	return result;
}

vector<Pokemon> PokedexSystem::merge(vector<Pokemon> left, vector<Pokemon> right, string sortingBy)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	vector<Pokemon> result;

	while ((int)left.size() > 0 || (int)right.size() > 0) {

		if ((int)left.size() > 0 && (int)right.size() > 0) {
			if (sortingBy == "natdex")
			{
				if ((int)left.front().returnDexNo() <= (int)right.front().returnDexNo()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}
				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}

			}
			if (sortingBy == "id")
			{
				if ((int)left.front().returnID() <= (int)right.front().returnID()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}
				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}

			}
			else if (sortingBy == "name")
			{
				if ((string)left.front().returnName() <= (string)right.front().returnName()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}

			else if (sortingBy == "type")
			{
				if ((string)left.front().returnTypes() <= (string)right.front().returnTypes()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}

		}
		else if ((int)left.size() > 0) {
			for (int i = 0; i < (int)left.size(); i++)
				result.push_back(left[i]);
			break;
		}
		else if ((int)right.size() > 0) {
			for (int i = 0; i < (int)right.size(); i++)
				result.push_back(right[i]);
			break;
		}
	}
	return result;
}

vector<evolvingPokemon> PokedexSystem::mergeSortEvolving(vector<evolvingPokemon> listToSort, string mergetype)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	// Follows the same logic, but optimised to handle a vector of Pokemon rather than ints

	// check to see if list is too small to sort
	if (listToSort.size() <= 1)
		return listToSort;

	vector<evolvingPokemon> left, right, result;

	int middle = ((int)listToSort.size() + 1) / 2;

	for (int i = 0; i < middle; i++) {
		left.push_back(listToSort[i]);
	}

	for (int i = middle; i < (int)listToSort.size(); i++) {
		right.push_back(listToSort[i]);
	}

	left = mergeSortEvolving(left, mergetype);
	right = mergeSortEvolving(right, mergetype);


	result = mergeEvolving(left, right, mergetype);

	return result;
}

vector<evolvingPokemon> PokedexSystem::mergeEvolving(vector<evolvingPokemon> left, vector<evolvingPokemon> right, string sortingBy)
{
	// Made using http://www.bogotobogo.com/Algorithms/mergesort.php as a base
	vector<evolvingPokemon> result;

	while ((int)left.size() > 0 || (int)right.size() > 0) {

		if ((int)left.size() > 0 && (int)right.size() > 0) {
			if (sortingBy == "natdex")
			{
				if ((int)left.front().returnDexNo() <= (int)right.front().returnDexNo()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}
				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}

			}
			if (sortingBy == "id")
			{
				if ((int)left.front().returnID() <= (int)right.front().returnID()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}
				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}

			}
			else if (sortingBy == "name")
			{
				if ((string)left.front().returnName() <= (string)right.front().returnName()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}

			else if (sortingBy == "type")
			{
				if ((string)left.front().returnTypes() <= (string)right.front().returnTypes()) {
					result.push_back(left.front());
					left.erase(left.begin());
				}

				else {
					result.push_back(right.front());
					right.erase(right.begin());
				}
			}

		}
		else if ((int)left.size() > 0) {
			for (int i = 0; i < (int)left.size(); i++)
				result.push_back(left[i]);
			break;
		}
		else if ((int)right.size() > 0) {
			for (int i = 0; i < (int)right.size(); i++)
				result.push_back(right[i]);
			break;
		}
	}
	return result;
}