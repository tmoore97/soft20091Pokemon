#pragma once

#include "stdafx.h"
#include <iostream>
#include <string>
using namespace std;


class Pokemon {
public:
	void setDetails(string a, int b, string c, string d, string e, bool f, size_t g);
	void displayDetails();
	string returnName();
	int returnDexNo();
	string returnTypes();
	string returnDate();
	bool returnEvolves();
	size_t returnID();
protected:
	string name;
	int natDexNo;
	string primType;
	string secType;
	string dateCaught;
	bool evolves;
	size_t ID;
};

class evolvingPokemon : public Pokemon {
public:
	string returnEvolutionTree();
	void setDetails(string a, int b, string c, string d, string e, bool f, size_t g, string h, string i);
	void displayDetails();
protected:
	string evolvesFrom;
	string evolvesInto;
};

class nonEvolvingPokemon : public Pokemon {
public:
	bool returnEvolves();
};
