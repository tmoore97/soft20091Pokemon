#include "stdafx.h"
#include "pokemon.h"

// Base Pokemon class functions
void Pokemon::setDetails(string a, int b, string c, string d, string e, bool f, size_t g)
{
	name = a;
	natDexNo = b;
	primType = c;
	secType = d;
	dateCaught = e;
	evolves = f;
	ID = g;
};

void Pokemon::displayDetails()
{
	cout << endl << "Name: " + name << " | " << "National Dex Number: " << natDexNo <<
		endl << "Primary Type: " + primType << " | " << "Secondary Type: " + secType <<
		endl << "Date Caught: " + dateCaught << " | " << "Evolves: No" << " | " << "ID: " << ID << endl;
};

string Pokemon::returnName()
{
	return name;
};

int Pokemon::returnDexNo()
{
	return natDexNo;
}

string Pokemon::returnTypes()
{
	string types = primType + "|" + secType;
	return types;
}

string Pokemon::returnDate()
{
	return dateCaught;
}

bool Pokemon::returnEvolves()
{
	return evolves;
}

size_t Pokemon::returnID()
{
	return ID;
}


// Evolving Pokemon class functions
string evolvingPokemon::returnEvolutionTree()
{
	return evolvesFrom + "|" + evolvesInto;
}
void evolvingPokemon::setDetails(string a, int b, string c, string d, string e, bool f, size_t g, string h, string i)
{
	name = a;
	natDexNo = b;
	primType = c;
	secType = d;
	dateCaught = e;
	evolves = f;
	ID = g;
	evolvesFrom = h;
	evolvesInto = i;
}
void evolvingPokemon::displayDetails()
{
	cout << endl << "Name: " + name << " | " << "National Dex Number: " << natDexNo <<
		endl << "Primary Type: " + primType << " | " << "Secondary Type: " + secType <<
		endl << "Date Caught: " + dateCaught << " | " << "Evolves: Yes" <<
		endl << "Evolves From: " + evolvesFrom << " | " << "Evolves Into: " + evolvesInto << endl;
}

// Non-evolving Pokemon class functions
bool nonEvolvingPokemon::returnEvolves()
{
	return false;
}

